"""
UniBot AI Chatbot Engine
Handles intent classification and response generation using NLP
"""

import json
import random
import re
import os
from typing import List, Dict, Tuple, Optional

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline


class ChatbotEngine:
    """
    The brain of UniBot - classifies user queries and generates responses.
    Uses TF-IDF + Naive Bayes for lightweight, fast intent classification.
    """
    
    def __init__(self, data_path: str = "data/university_data.json"):
        self.data_path = data_path
        self.intents: List[Dict] = []
        self.model: Optional[Pipeline] = None
        self.tag_responses: Dict[str, List[str]] = {}
        self.conversation_context: Dict = {"last_topic": None}
        
        self._load_data()
        self._train_model()
    
    def _load_data(self) -> None:
        """Load university data from JSON file."""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, self.data_path)
        
        with open(full_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        self.intents = data['intents']
        
        for intent in self.intents:
            self.tag_responses[intent['tag']] = intent['responses']
    
    def _preprocess_text(self, text: str) -> str:
        """
        Clean and normalize user input text.
        Steps: lowercase, remove extra spaces, remove special characters.
        """
        text = text.lower()
        text = re.sub(r'\s+', ' ', text).strip()
        text = re.sub(r'[^a-zA-Z0-9\s\?\.,]', '', text)
        return text
    
    def _train_model(self) -> None:
        """
        Train the intent classification model.
        Uses TF-IDF to convert text to numerical features,
        then Naive Bayes to classify intent tags.
        """
        training_sentences: List[str] = []
        training_tags: List[str] = []
        
        for intent in self.intents:
            for pattern in intent['patterns']:
                training_sentences.append(self._preprocess_text(pattern))
                training_tags.append(intent['tag'])
        
        self.model = Pipeline([
            ('tfidf', TfidfVectorizer(
                ngram_range=(1, 2),
                max_features=1000,
                stop_words='english'
            )),
            ('classifier', MultinomialNB())
        ])
        
        self.model.fit(training_sentences, training_tags)
        print(f"Model trained on {len(training_sentences)} patterns across {len(set(training_tags))} intents.")
    
    def _predict_intent(self, text: str) -> Tuple[str, float]:
        """
        Predict the intent tag for a given user message.
        Returns: (predicted_tag, confidence_score)
        """
        clean_text = self._preprocess_text(text)
        
        predicted_tag = self.model.predict([clean_text])[0]
        
        probabilities = self.model.predict_proba([clean_text])[0]
        confidence = np.max(probabilities)
        
        return predicted_tag, float(confidence)
    
    def _get_response(self, tag: str, user_message: str = "") -> str:
        """
        Get a random response for the predicted intent tag.
        If confidence is too low, return the unknown response.
        """
        if tag in self.tag_responses:
            responses = self.tag_responses[tag]
            return random.choice(responses)
        
        return random.choice(self.tag_responses.get('unknown', ["I'm not sure about that."]))
    
    def _extract_entities(self, message: str) -> Dict[str, str]:
        """
        Extract relevant entities from user message.
        E.g., department names, semester numbers, etc.
        """
        entities = {}
        
        semester_match = re.search(r'\b(\d+)(?:st|nd|rd|th)?\s*sem(?:ester)?\b', message.lower())
        if semester_match:
            entities['semester'] = semester_match.group(1)
        
        departments = ['cs', 'computer science', 'it', 'software engineering', 'se', 'ee', 'electrical']
        for dept in departments:
            if dept in message.lower():
                entities['department'] = dept
                break
        
        return entities
    
    def process_message(self, message: str) -> Dict:
        """
        Main entry point: process a user message and return a response.
        
        Returns a dictionary with:
        - response: The chatbot's reply
        - intent: The detected intent tag
        - confidence: How sure the bot is (0.0 to 1.0)
        - entities: Extracted entities from the message
        """
        intent_tag, confidence = self._predict_intent(message)
        
        entities = self._extract_entities(message)
        
        if confidence < 0.3:
            intent_tag = 'unknown'
        
        response = self._get_response(intent_tag, message)
        
        if intent_tag != 'greeting' and intent_tag != 'goodbye' and intent_tag != 'unknown':
            self.conversation_context['last_topic'] = intent_tag
        
        return {
            'response': response,
            'intent': intent_tag,
            'confidence': round(confidence, 3),
            'entities': entities
        }
    
    def extract_entities(self, message: str) -> Dict[str, str]:
        """Extract relevant entities from user message."""
        return self._extract_entities(message)
    
    def get_suggestions(self) -> List[str]:
        """Return quick-reply suggestions for the user."""
        return [
            "Admission requirements",
            "Fee structure",
            "CS courses",
            "Exam schedule",
            "Library timing",
            "Hostel facilities"
        ]
