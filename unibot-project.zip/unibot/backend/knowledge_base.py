"""
Knowledge Base Module
Handles loading and querying university data.
"""

import json
import os
from typing import List, Dict, Optional


class KnowledgeBase:
    """
    Manages university data including intents, patterns, and responses.
    Can be extended to load from databases or external APIs.
    """
    
    def __init__(self, data_path: str = "data/university_data.json"):
        self.data_path = data_path
        self.data: Dict = {}
        self.intents: List[Dict] = []
        self._load()
    
    def _load(self) -> None:
        """Load data from JSON file."""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, self.data_path)
        
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
            self.intents = self.data.get('intents', [])
            print(f"Loaded {len(self.intents)} intents from knowledge base.")
        except FileNotFoundError:
            print(f"Warning: Knowledge base file not found at {full_path}")
            self.data = {'intents': []}
            self.intents = []
    
    def get_intent_by_tag(self, tag: str) -> Optional[Dict]:
        """Find an intent by its tag."""
        for intent in self.intents:
            if intent['tag'] == tag:
                return intent
        return None
    
    def get_all_tags(self) -> List[str]:
        """Get list of all intent tags."""
        return [intent['tag'] for intent in self.intents]
    
    def search_by_keyword(self, keyword: str) -> List[Dict]:
        """Search intents containing a keyword in patterns."""
        results = []
        keyword_lower = keyword.lower()
        
        for intent in self.intents:
            for pattern in intent.get('patterns', []):
                if keyword_lower in pattern.lower():
                    results.append(intent)
                    break
        
        return results
    
    def reload(self) -> None:
        """Reload data from file (useful for live updates)."""
        self._load()
