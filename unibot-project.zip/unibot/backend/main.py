"""
UniBot FastAPI Server
REST API backend for the university chatbot.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime

from chatbot_engine import ChatbotEngine
from knowledge_base import KnowledgeBase

# Initialize FastAPI app
app = FastAPI(
    title="UniBot API",
    description="AI-powered University Helpdesk Chatbot API",
    version="1.0.0"
)

# Enable CORS - allows frontend to communicate with backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize chatbot engine (loaded once when server starts)
chatbot = ChatbotEngine()
kb = KnowledgeBase()

# --- Pydantic Models ---

class ChatMessage(BaseModel):
    """Model for incoming chat messages."""
    message: str
    user_id: Optional[str] = "anonymous"


class ChatResponse(BaseModel):
    """Model for chatbot responses."""
    response: str
    intent: str
    confidence: float
    entities: Dict[str, str]
    timestamp: str


class SuggestionsResponse(BaseModel):
    """Model for quick-reply suggestions."""
    suggestions: List[str]


# --- API Endpoints ---

@app.get("/")
async def root():
    """Root endpoint - API health check."""
    return {
        "status": "online",
        "service": "UniBot API",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    }


@app.get("/health")
async def health_check():
    """Health check endpoint for monitoring."""
    return {
        "status": "healthy",
        "model_loaded": chatbot.model is not None,
        "intents_count": len(chatbot.intents),
        "timestamp": datetime.now().isoformat()
    }


@app.post("/chat", response_model=ChatResponse)
async def chat(message: ChatMessage):
    """
    Main chat endpoint.
    Send a user message and get the chatbot's response.
    """
    try:
        result = chatbot.process_message(message.message)
        
        return ChatResponse(
            response=result['response'],
            intent=result['intent'],
            confidence=result['confidence'],
            entities=result['entities'],
            timestamp=datetime.now().isoformat()
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Chatbot error: {str(e)}")


@app.get("/suggestions", response_model=SuggestionsResponse)
async def get_suggestions():
    """Get quick-reply suggestion buttons."""
    return SuggestionsResponse(suggestions=chatbot.get_suggestions())


@app.get("/intents")
async def get_intents():
    """Get all available intent tags (for debugging/admin)."""
    return {
        "intents": kb.get_all_tags(),
        "count": len(kb.get_all_tags())
    }


# --- Run the Server ---

if __name__ == "__main__":
    import uvicorn
    
    print("=" * 50)
    print("  UniBot Server Starting...")
    print("  API Docs: http://localhost:8000/docs")
    print("  Chat API: http://localhost:8000/chat")
    print("=" * 50)
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
